package lognoziroh.bindingModel;

public class ReportBindingModel {
	//TODO: Implement me ...
}
