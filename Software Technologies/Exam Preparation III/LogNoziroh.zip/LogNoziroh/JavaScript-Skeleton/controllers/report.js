const Report = require('../models').Report;

module.exports = {
    index: (req, res) => {
        //TODO
    },
    createGet: (req, res) => {
        //TODO
    },
    createPost: (req, res) => {
        //TODO
    },
    detailsGet: (req, res) => {
        //TODO
    },
    deleteGet: (req, res) => {
        //TODO

    },
    deletePost: (req, res) => {
        //TODO
    }
};