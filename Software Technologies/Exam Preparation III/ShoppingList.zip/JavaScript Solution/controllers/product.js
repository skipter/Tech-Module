const Product = require('../models').Product;

module.exports = {
	index: (req, res) => {

	},

	createGet: (req, res) => {

	},

	createPost: (req, res) => {

	},

	editGet: (req, res) => {

	},

	editPost: (req, res) => {

	}
};