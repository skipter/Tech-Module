﻿namespace ShoppingList.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Product
    {
    }
}
