package projectrider.bindingModel;

public class ProjectBindingModel {

    // TODO

}
