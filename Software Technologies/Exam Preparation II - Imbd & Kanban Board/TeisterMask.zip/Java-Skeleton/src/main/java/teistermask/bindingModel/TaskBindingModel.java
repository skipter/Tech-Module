package teistermask.bindingModel;

public class TaskBindingModel {
    // TODO
}
