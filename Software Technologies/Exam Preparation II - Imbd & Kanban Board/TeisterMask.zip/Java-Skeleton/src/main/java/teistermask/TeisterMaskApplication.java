package teistermask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeisterMaskApplication {
	public static void main(String[] args) {
		SpringApplication.run(TeisterMaskApplication.class, args);
	}
}
