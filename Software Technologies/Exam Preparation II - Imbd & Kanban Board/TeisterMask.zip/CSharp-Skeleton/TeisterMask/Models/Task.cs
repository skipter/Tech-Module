﻿namespace TeisterMask.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Task
    {
    }
}
